﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = "Server=DESKTOP-4LF9R5N\\SQLEXPRESS02;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
